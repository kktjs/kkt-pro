const Layout = (props) => {
  console.log('Layout', props);
  return props.children;
};
export default Layout;
