const Auth = (props) => {
  console.log('auth', props);
  return props.children;
};
export default Auth;
