import { Icons } from '@kkt/pro';

const Index = () => {
  return (
    <div>
      <Icons type="add" />
      home
    </div>
  );
};
export default Index;
