const Page = () => {
  return <div>loading...</div>;
};

export default Page;
