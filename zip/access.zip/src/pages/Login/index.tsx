const App = () => {
  console.log(6778);
  return <div>this is login</div>;
};
App.loader = async () => {
  console.log('::进入页面请求API:');
};
export default App;
