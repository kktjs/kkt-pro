const Index = () => {
  return <div>about</div>;
};
export default Index;
