const App = () => {
  return <div className="App">通用匹配</div>;
};

export default App;
