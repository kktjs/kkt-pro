const global = {
  name: 'demo',
  state: {},
  reducers: {},
  effects: (dispatch) => ({}),
};
export default global;
