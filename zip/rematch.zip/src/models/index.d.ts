const store = {
  name: '2222',
  state: {},
};
export default store;
