const About = (props: any) => {
  console.log(11, props);
  return <div>测试页面</div>;
};
export default About;
