const store = {
  name: '2222',
};
export default store;
