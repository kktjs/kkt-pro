const Index = (props: any) => {
  return props.children;
};
export default Index;
