const Auth = (props) => {
  return props.children;
};
export default Auth;
